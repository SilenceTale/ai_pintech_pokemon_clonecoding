package org.koreait.member.constants;

public enum Gender {
    FEMALE,
    MALE,
    SECRET
}
