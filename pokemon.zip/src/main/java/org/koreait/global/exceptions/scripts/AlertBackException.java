package org.koreait.global.exceptions.scripts;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;

/**
 * 예외가 발생하면 alert("message"); target.history.back(); 을 실행함
 */
@Getter @Setter
public class AlertBackException extends AlertException {
    private String target;

    public AlertBackException(String message, HttpStatus status, String target) {
        super(message, status);

        target = StringUtils.hasText(target) ? target : "self"; // 기본값은 현재 창에서 이동한다.
        this.target = target;

    }
}
